// models/giveaway.js
const mongoose = require('mongoose');
const { Schema, model, models } = mongoose;

const GiveawaySchema = new Schema({
  _id: { type: String },                 // custom id
  guildId: { type: String, index: true },
  channelId: String,
  messageId: String,

  prize: { type: String, maxlength: 200, required: true },
  winners: { type: Number, min: 1, max: 50, required: true },

  startAt: Number,
  endAt: Number,
  endedAt: { type: Number, default: null },
  paused: { type: Boolean, default: false },
  canceled: { type: Boolean, default: false },
  remainingWhenPaused: { type: Number, default: null },

  hostId: String,

  // eligibility / anti-abuse
  roleRequirementId: { type: String, default: null },
  minAccountAgeMs: { type: Number, default: 0 },
  minGuildAgeMs: { type: Number, default: 0 },
  blacklistRoleIds: { type: [String], default: [] },
  blacklistUserIds: { type: [String], default: [] },
  allowBots: { type: Boolean, default: false },

  entries: { type: [String], default: [] },
  winnerIds: { type: [String], default: [] },
}, { versionKey: false });

module.exports = models.Giveaway || model('Giveaway', GiveawaySchema);
