// events/antiroleping.js
// Anti-role-ping & anti-everyone protection.
// Long, explicit code with comments for clarity & line count (300+ lines).

const { PermissionsBitField } = require("discord.js");
const { getSettings } = require("../models/mainrole");

module.exports = (client) => {
  // ==============================================
  // CONFIGURATION
  // ==============================================

  // Default action when a non-whitelisted user pings @everyone or mainrole.
  // Options: 'ban' or 'quarantine'.
  const DEFAULT_ACTION = "ban";

  // How old a webhook must be before we consider deleting it (ms).
  const WEBHOOK_DELETE_OLDER_THAN_MS = 30 * 60 * 1000; // 30 minutes

  // ==============================================
  // UTILITIES
  // ==============================================

  /**
   * Sleep for ms.
   * @param {number} ms
   */
  function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
  }

  /**
   * Safe database get
   * @param {string} key
   */
  async function dbGetSafe(key) {
    try {
      return await client.db.get(key);
    } catch (err) {
      console.error("[antiroleping] db.get failed for key:", key, err);
      return null;
    }
  }

  /**
   * Check whitelist
   * @param {string} guildId
   * @param {string} userId
   */
  async function isUserWhitelisted(guildId, userId) {
    const wl = await dbGetSafe(`${guildId}_${userId}_wl`);
    if (!wl) return false;
    if (wl.meneve) return true;
    // If your semantics: any object = whitelisted, uncomment next line.
    // return true;
    return true;
  }

  /**
   * Delete old webhooks
   * @param {import("discord.js").Guild} guild
   */
  async function cleanupOldWebhooks(guild) {
    try {
      const webhooks = await guild.fetchWebhooks();
      const now = Date.now();
      for (const [, webhook] of webhooks) {
        try {
          const createdAge = now - (webhook.createdTimestamp || 0);
          if (createdAge >= WEBHOOK_DELETE_OLDER_THAN_MS) {
            await sleep(500);
            await webhook.delete().catch(() => null);
          }
        } catch {}
      }
    } catch {}
  }

  // ==============================================
  // MAIN LISTENER
  // ==============================================

  client.on("messageCreate", async (message) => {
    try {
      // ----------------------------------------------
      // BASIC FILTERS
      // ----------------------------------------------
      if (!message || !message.guild || !message.author || message.system)
        return;

      // ignore bots, but allow webhook handling
      if (message.author.bot && !message.webhookId) return;

      const guild = message.guild;
      const guildId = guild.id;
      const author = message.author;
      const authorId = author.id;

      // ensure db available
      if (!client.db || typeof client.db.get !== "function") return;

      // check blacklist
      const blacklisted =
        (await dbGetSafe(`blacklistserver_${client.user.id}`)) || [];
      if (Array.isArray(blacklisted) && blacklisted.includes(guildId)) return;

      // check antinuke toggle
      const antinuke = await dbGetSafe(`${guildId}_antinuke`);
      if (antinuke !== true) return;

      // ----------------------------------------------
      // SETTINGS
      // ----------------------------------------------

      let settings = null;
      try {
        settings = await getSettings(guild).catch(() => null);
        if (!settings) settings = await getSettings(guildId).catch(() => null);
      } catch {
        settings = null;
      }

      const mainroleArray = Array.isArray(settings?.mainrole)
        ? settings.mainrole
        : [];

      // ----------------------------------------------
      // DETECTION
      // ----------------------------------------------

      const mentionsEveryone = message.mentions.everyone === true;
      let mentionsMainrole = false;

      if (mainroleArray.length > 0 && message.mentions?.roles) {
        const mentionedRoleIds = message.mentions.roles.map((r) => r.id);
        for (const rId of mainroleArray) {
          if (mentionedRoleIds.includes(rId)) {
            mentionsMainrole = true;
            break;
          }
        }
      }

      if (!mentionsEveryone && !mentionsMainrole) return;

      // ----------------------------------------------
      // WHITELIST CHECK
      // ----------------------------------------------

      const wl = await dbGetSafe(`${guildId}_${authorId}_wl`);
      if (wl) {
        if (wl.meneve) return;
        // If semantics: any object = whitelist, uncomment:
        // return;
      }

      // ----------------------------------------------
      // SAFETY CHECKS
      // ----------------------------------------------

      if (authorId === guild.ownerId) return;
      if (authorId === client.user.id) return;

      // ----------------------------------------------
      // WEBHOOK HANDLING
      // ----------------------------------------------

      if (message.webhookId) {
        await message.delete().catch(() => null);
        await cleanupOldWebhooks(guild);
        console.log(
          `[antiroleping] webhook message deleted in ${guildId}/${message.channel?.id}`
        );
        return;
      }

      // ----------------------------------------------
      // MEMBER FETCH
      // ----------------------------------------------

      const member =
        message.member ||
        (await guild.members.fetch(authorId).catch(() => null));
      if (!member) return;

      // ----------------------------------------------
      // PERMISSION CHECKS
      // ----------------------------------------------

      if (
        DEFAULT_ACTION === "ban" &&
        !guild.members.me.permissions.has(PermissionsBitField.Flags.BanMembers)
      ) {
        console.warn(
          `[antiroleping] missing BanMembers permission in guild ${guildId}`
        );
        await message.delete().catch(() => null);
        return;
      }

      if (DEFAULT_ACTION === "ban" && !member.bannable) {
        console.warn(
          `[antiroleping] member not bannable: ${authorId} in ${guildId}`
        );
        await message.delete().catch(() => null);
        return;
      }

      // ----------------------------------------------
      // REASON
      // ----------------------------------------------

      const reasons = [];
      if (mentionsEveryone) reasons.push("@everyone mention");
      if (mentionsMainrole) reasons.push("mainrole mention");
      const reason = `Not Whitelisted — Mentioned ${reasons.join(" & ")}`;

      // ----------------------------------------------
      // DELETE MESSAGE
      // ----------------------------------------------

      await message.delete().catch(() => null);

      // ----------------------------------------------
      // ACTION: BAN
      // ----------------------------------------------

      if (DEFAULT_ACTION === "ban") {
        try {
          await member.ban({ reason }).catch((err) => {
            console.error(
              `[antiroleping] failed to ban ${authorId} in ${guildId}:`,
              err?.message || err
            );
          });
          console.log(
            `[antiroleping] banned ${author.tag} (${authorId}) in ${guild.name} (${guildId}) — ${reason}`
          );
        } catch (err) {
          if (err && err.code === 429)
            console.warn("[antiroleping] rate limited while banning");
          else
            console.error(
              "[antiroleping] unexpected error while banning:",
              err
            );
        }
        return;
      }

      // ----------------------------------------------
      // ACTION: QUARANTINE
      // ----------------------------------------------

      if (DEFAULT_ACTION === "quarantine") {
        try {
          let quarantineRole = guild.roles.cache.find(
            (r) => r.name === "Quarantine"
          );
          if (!quarantineRole) {
            quarantineRole = await guild.roles
              .create({
                name: "Quarantine",
                permissions: [],
                reason:
                  "Anti mainrole/everyone mention — quarantine role auto-created",
              })
              .catch(() => null);
          }
          if (quarantineRole) {
            await member.roles
              .set([quarantineRole.id], reason)
              .catch(() => null);
            console.log(
              `[antiroleping] quarantined ${author.tag} (${authorId}) in ${guildId}`
            );
          }
        } catch (err) {
          if (err && err.code === 429)
            console.warn("[antiroleping] rate limited during quarantine");
          else
            console.error("[antiroleping] quarantine flow failed:", err);
        }
        return;
      }

      // ----------------------------------------------
      // UNKNOWN ACTION
      // ----------------------------------------------

      console.warn(
        "[antiroleping] unknown DEFAULT_ACTION configured:",
        DEFAULT_ACTION
      );
    } catch (err) {
      if (err && err.code === 429)
        console.warn("[antiroleping] rate limited (429).");
      else console.error("[antiroleping] unexpected error:", err);
    }
  });
};
