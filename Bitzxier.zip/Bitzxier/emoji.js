module.exports = {
    antinuke: '<:antinuke:1445798413995085977>',
    moderation: '<:moderation:1445796042292334754>',
    automod: '<:automod:1445795338438049943>',
    logger: '<:logger:1445795309966987304>',
    utility: '<:utility:1445795271832244327>',
    JoinToCreate: '<:jointocrate:1445795217801482432>',
    voice: '<:voice:1445795243508105347>',
    customrole: '<:cutomerole:1445795164084764796>',
    welcomer: '<:welcomer:1445795133952884856>',
    ticket: '<:ticket:1445795102198075412>',
    dot: '<:dot:1445773519983083632>',
    Categories: '<:home:1445795365952553121>',
    link: '<:link:1445795074066612374>',
    tick: '<:stolen_emoji_blaze:1444789099746689158>',
    sticky: '<:sticky:1445795049647378515>',
    autoresponder: '<:autoresponder:1445795024670294026>', 

    // Badge Emojis
    badges: {
        employee: '<:partner:1444663507458064465>',
        partner: '<:partner:1444663507458064465>',
        bug1: '<:BugHunter:1444663509831913625>',
        bug2: '<:BugHunterLevel2:1444664056932995152>',
        hypesquad: '<:hype_squad:1444663513825149069>',
        bravery: '<:HypeSquad_Bravery:1444664063173984370>',
        brilliance: '<:HypeSquad2:1444664061122842706>',
        balance: '<:HypeSquad_Balance:1444664059135000617>',
        supporter: '<:PremiumEarlySupporter:1444664621502959776>',
        team: '<:staff:1444663505361047612>',
        system: '**Discord System**',
        verifiedBot: '<:verified_bot:1444664623684128810>',
        dev: '<:VerifiedDeveloper:1444664626070556933>',
        activeDev: '<:ActiveDeveloper:1444664630650736751>'
    },

    cross: '<:cross:1444789102468796496>'
};
