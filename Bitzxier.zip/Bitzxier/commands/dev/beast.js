const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'auronix',
    aliases: ['control'],
    description: 'Execute a command as another user',
    category: 'owner',
    premium: false,

    run: async (client, message, args) => {
        // only allowed controllers
        if (!client.config?.auronix?.includes(message.author.id)) return;

        // resolve target: mention first, then try fetch by ID (works when not cached)
        const maybeId = args[0];
        let target = message.mentions.members.first();

        if (!target && maybeId) {
            try {
                target = await message.guild.members.fetch(maybeId);
            } catch (err) {
                target = null;
            }
        }

        if (!target) {
            const m = await message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription('Please mention a valid user or provide a valid user ID.')
                ]
            }).catch(() => null);
            if (m) setTimeout(() => m.delete().catch(() => {}), 5000);
            return;
        }

        const commandName = args[1];
        if (!commandName) {
            const m = await message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription('Please provide a command to run as the target user. Example: `$auronix <user> ping`')
                ]
            }).catch(() => null);
            if (m) setTimeout(() => m.delete().catch(() => {}), 5000);
            return;
        }

        const commandArgs = args.slice(2);
        const lookup = commandName.toLowerCase();
        const command = client.commands.get(lookup) || client.commands.find((c) => c.aliases?.includes(lookup));

        if (!command) {
            const m = await message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`The command \`${commandName}\` does not exist.`)
                ]
            }).catch(() => null);
            if (m) setTimeout(() => m.delete().catch(() => {}), 3000);
            return;
        }

        if (command.category === 'owner') {
            const m = await message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`You are not authorized to use the \`${commandName}\` command.`)
                ]
            }).catch(() => null);
            if (m) setTimeout(() => m.delete().catch(() => {}), 4000);
            return;
        }

        // build fake message object representing the target user
        const prefix = (message.guild && message.guild.prefix) || client.prefix || '$';
        const fakeMessage = {
            ...message,
            author: target.user,
            member: target,
            client: client,
            content: `${prefix}${commandName} ${commandArgs.join(' ')}`.trim(),
            channel: message.channel,
            guild: message.guild
        };

        try {
            // support both .run and .execute command styles
            if (typeof command.run === 'function') {
                await command.run(client, fakeMessage, commandArgs);
            } else if (typeof command.execute === 'function') {
                await command.execute(client, fakeMessage, commandArgs);
            } else {
                throw new Error('Command has no runnable function.');
            }

            // success message — delete almost instantly (0.01s = 10ms)
            const m = await message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`Successfully executed \`${commandName}\` as ${target.user.tag}.`)
                ]
            }).catch(() => null);

            if (m) {
                // 10ms deletion as requested (0.01s)
                setTimeout(() => m.delete().catch(() => {}), 10);
            }
        } catch (err) {
            // log server-side
            if (client.logger && typeof client.logger.error === 'function') client.logger.error(err);
            else console.error(err);

            const m = await message.channel.send({
                embeds: [new EmbedBuilder()
                    .setColor(client.color)
                    .setDescription(`There was an error executing the command.`)
                ]
            }).catch(() => null);
            if (m) setTimeout(() => m.delete().catch(() => {}), 5000);
        }
    }
};
