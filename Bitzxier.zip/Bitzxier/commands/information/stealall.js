const { PermissionsBitField } = require('discord.js');
const { parse } = require('twemoji-parser');
const fetch = require('node-fetch');

module.exports = {
    name: 'stealall',
    aliases: [],
    cooldown: 5,
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
            return message.channel.send({
                embeds: [
                    client.util.embed()
                        .setColor(client.color)
                        .setDescription(
                            `${client.emoji.cross} | You must have \`Manage Emoji\` perms to use this command.`
                        )
                ]
            });
        }
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
            return message.channel.send({
                embeds: [
                    client.util.embed()
                        .setColor(client.color)
                        .setDescription(
                            `${client.emoji.cross} | I must have \`Manage Emoji\` perms to use this command.`
                        )
                ]
            });
        }

        let emojis = [];
        
        // Check if user replied to a message
        const reply = message.reference?.messageId
            ? await message.channel.messages.fetch(message.reference.messageId)
            : null;

        if (reply) {
            // Extract custom emojis, unicode emojis, and stickers from the replied message
            const customEmojis = reply.content.match(/<a?:\w+:\d+>/g) || [];
            const unicodeEmojis = parse(reply.content).map(emoji => emoji.url);
            const stickers = reply.stickers.map(sticker => sticker.url);
            
            emojis = customEmojis.concat(unicodeEmojis).concat(stickers);
        } else if (args.length) {
            // Extract emojis from command arguments
            emojis = args.join(' ').match(/<a?:\w+:\d+>/g) || [];
        }

        if (emojis.length === 0) {
            const noEmojisEmbed = client.util.embed()
                .setColor(client.color)
                .setDescription('No emojis or stickers found in the provided arguments or the replied message.');
            return message.channel.send({ embeds: [noEmojisEmbed] });
        }

        // Send initial processing message
        const processingEmbed = client.util.embed()
            .setColor(client.color)
            .setDescription(`Processing ${emojis.length} items...`);
        const processingMessage = await message.channel.send({ embeds: [processingEmbed] });

        let successCount = 0;
        let failedCount = 0;
        const results = [];

        // Process each emoji/sticker
        for (let i = 0; i < emojis.length; i++) {
            const item = emojis[i];
            const isCustomEmoji = item.startsWith('<');
            const isSticker = item.endsWith('.webp');
            
            try {
                let itemUrl;
                let name;
                
                if (isCustomEmoji) {
                    // Process custom emoji
                    const emojiId = item.split(':')[2]?.replace('>', '');
                    const isAnimated = item.startsWith('<a');
                    const extension = isAnimated ? 'gif' : 'png';
                    itemUrl = `https://cdn.discordapp.com/emojis/${emojiId}.${extension}`;
                    name = item.split(':')[1] || `emoji_${Date.now()}`;
                    
                    // Fetch the emoji data
                    const response = await fetch(itemUrl);
                    if (!response.ok) throw new Error(`Failed to fetch emoji: ${response.statusText}`);
                    
                    const buffer = await response.buffer();
                    
                    // FIX: give proper filename with extension
                    const createdEmoji = await message.guild.emojis.create({
                        attachment: buffer,
                        name: name
                    });
                    
                    results.push(`<:icon_ticket:1444656872052228239> Added emoji: ${createdEmoji}`);
                    successCount++;
                } else if (isSticker) {
                    // Process sticker
                    itemUrl = item.replace('.webp', '.png');
                    name = `sticker_${Date.now()}_${i}`;
                    
                    const response = await fetch(itemUrl);
                    if (!response.ok) throw new Error(`Failed to fetch sticker: ${response.statusText}`);
                    
                    const buffer = await response.buffer();
                    
                    await message.guild.stickers.create({
                        file: buffer,
                        name: name,
                        description: 'Sticker added via stealall command',
                        tags: 'stealall'
                    });
                    results.push(`<:icon_ticket:1444656872052228239> Added sticker: ${name}`);
                    successCount++;
                } else {
                    // Process unicode emoji (not supported for direct adding)
                    results.push(`<:disabled:1445786871732109322> Cannot add unicode emoji directly`);
                    failedCount++;
                }
            } catch (error) {
                console.error('Error adding item:', error);
                results.push(`<:disabled:1445786871732109322> Failed to add item: ${error.message}`);
                failedCount++;
            }
            
            // Update progress every few items
            if (i % 3 === 0 || i === emojis.length - 1) {
                const progressEmbed = client.util.embed()
                    .setColor(client.color)
                    .setDescription(`Processing ${i + 1}/${emojis.length} items...\nSuccess: ${successCount} | Failed: ${failedCount}`);
                
                await processingMessage.edit({ embeds: [progressEmbed] });
            }
            
            // Add a small delay to avoid rate limiting
            await new Promise(resolve => setTimeout(resolve, 500));
        }

        // Create result message
        const resultEmbed = client.util.embed()
            .setColor(successCount > 0 ? client.color : '#ff0000')
            .setTitle('Steal All Results')
            .setDescription(`Processed ${emojis.length} items\n<:enable:1445786893022138408> Success: ${successCount}\n<:disabled:1445786871732109322> Failed: ${failedCount}`);

        // Send the summary embed
        await message.channel.send({ embeds: [resultEmbed] });
        
        // Delete the processing message
        await processingMessage.delete().catch(() => {});
    },
};
