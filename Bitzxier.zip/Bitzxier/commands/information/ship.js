const fetch = require('node-fetch'); // v2 (CommonJS)
const canvafy = require('canvafy');

module.exports = {
  name: 'ship',
  aliases: ['shiprandom'],
  category: 'info',
  cooldown: 8,
  premium: false,

  run: async (client, message, args) => {
    try {
      // Helper: fetch image URL -> Buffer
      async function fetchImageBuffer(url) {
        try {
          const res = await fetch(url);
          if (!res.ok) throw new Error(`HTTP ${res.status}`);
          const buf = await res.buffer();
          return buf;
        } catch (err) {
          console.warn(`Failed to fetch image ${url}:`, err.message);
          return null;
        }
      }

      // Helper: fetch member from mention or id
      async function fetchMemberFromArg(arg) {
        if (!arg) return null;
        const mentionMatch = arg.match(/^<@!?(\d+)>$/);
        if (mentionMatch) {
          const id = mentionMatch[1];
          return await message.guild.members.fetch(id).catch(() => null);
        }
        if (/^\d+$/.test(arg)) {
          return await message.guild.members.fetch(arg).catch(() => null);
        }
        return null;
      }

      // Choose target member
      let targetMember = null;
      if (args[0]) {
        if (args[0].toLowerCase() === 'random') {
          const members = message.guild.members.cache
            .filter(m => !m.user.bot && m.id !== message.author.id)
            .map(m => m);
          if (!members.length) return message.channel.send('❌ No other members found to ship with!');
          targetMember = members[Math.floor(Math.random() * members.length)];
        } else {
          targetMember = await fetchMemberFromArg(args[0]);
          if (!targetMember) return message.channel.send('❌ User not found! Please mention a user, provide their ID, or use `random`.');
        }
      } else {
        const members = message.guild.members.cache
          .filter(m => !m.user.bot && m.id !== message.author.id)
          .map(m => m);
        if (!members.length) return message.channel.send('❌ No other members found to ship with!');
        targetMember = members[Math.floor(Math.random() * members.length)];
      }

      const targetUser = targetMember.user;

      // Avatar URLs (PNG, good resolution)
      const authorAvatarURL = message.author.displayAvatarURL({ forceStatic: true, extension: 'png', size: 512 });
      const memberAvatarURL = targetUser.displayAvatarURL({ forceStatic: true, extension: 'png', size: 512 });

      // Fetch avatars as buffers
      const [authorBuf, memberBuf] = await Promise.all([
        fetchImageBuffer(authorAvatarURL),
        fetchImageBuffer(memberAvatarURL)
      ]);

      if (!authorBuf || !memberBuf) {
        return message.channel.send('❌ Failed to fetch one or both avatars. Try again later.');
      }

      // Background: your discord CDN link converted to request PNG
      const backgroundURL = 'https://media.discordapp.net/attachments/1189308460072960140/1303644352270041129/OIP_22.png?format=png&width=593&height=333';
      const backgroundBuf = await fetchImageBuffer(backgroundURL);

      // Generate love percentage and description
      const lovePercentage = Math.floor(Math.random() * 101); // 0-100 inclusive
      const relationshipDescriptions = [
        "A relationship is plausible!", "Sparks are definitely flying!",
        "Maybe better as friends?", "True love is in the air!", "Opposites attract!",
        "A fiery passion awaits!", "The beginning of something magical!",
        "A perfect match made in heaven!", "They can't keep their eyes off each other!",
        "Love isn't always easy...", "They're each other's better half!",
        "Destined to be together!", "They'll be the funniest couple around!",
        "They complete each other!", "A cosmic connection!", "Love at first sight!",
        "They bring out the best in each other!", "Party couple vibes!",
        "Fingers crossed for a fairytale ending!", "They're bound to make memories together!",
        "Love like no other!", "A wholesome, sweet connection!", "A subtle yet powerful bond!",
        "Sparks of excitement fill the air!"
      ];
      const randomLine = relationshipDescriptions[Math.floor(Math.random() * relationshipDescriptions.length)];

      // Build ship image using canvafy, pass Buffers
      const shipBuilder = new canvafy.Ship()
        .setAvatars(authorBuf, memberBuf)
        .setOverlayOpacity(0.5)
        .setCustomNumber(lovePercentage);

      if (backgroundBuf) {
        shipBuilder.setBackground('image', backgroundBuf);
      } else {
        // Fallback to a plain color background if fetching fails
        try {
          shipBuilder.setBackground('color', '#1f1f1f');
        } catch (e) {
          // Some versions may not accept 'color' -> ignore and continue
          console.warn('Could not set color background; proceeding with default.', e.message);
        }
      }

      const ship = await shipBuilder.build();

      const authorTag = `${message.author.username}#${message.author.discriminator}`;
      const targetTag = `${targetUser.username}#${targetUser.discriminator}`;

      await message.reply({
        content: `**${authorTag}** + **${targetTag}** = ${lovePercentage}% 💗\n${randomLine}`,
        files: [{ attachment: ship, name: 'ship-image.png' }]
      });
    } catch (err) {
      console.error('Ship command error:', err);
      return message.channel.send('❌ Something went wrong while generating the ship image.');
    }
  }
};
