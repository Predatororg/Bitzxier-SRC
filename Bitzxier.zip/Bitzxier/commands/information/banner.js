const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, ComponentType } = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'banner',
    aliases: [],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        try {
            let user;

            // If user is provided (mention or ID)
            if (args[0]) {
                const mentioned = await getUserFromMention(message, args[0]);
                if (mentioned) {
                    user = mentioned;
                } else {
                    try {
                        user = await client.users.fetch(args[0]); // Fetch user by ID
                    } catch (error) {
                        user = message.author; // Default to the message author
                    }
                }
            } else {
                user = message.author; // If no args, default to message sender
            }

            // Fetch user data to get the user banner
            const userData = await axios
                .get(`https://discord.com/api/users/${user.id}`, {
                    headers: {
                        Authorization: `Bot ${client.token}`,
                    },
                })
                .then((res) => res.data)
                .catch(() => null);

            const userBanner = userData && userData.banner
                ? `https://cdn.discordapp.com/banners/${user.id}/${userData.banner}${
                    userData.banner.startsWith('a_') ? '.gif' : '.png'
                }?size=4096`
                : null;

            // Try fetching guild-specific avatar/banner (if exists)
            let serverBanner = null;
            try {
                const guildMemberData = await client.snek.get(
                    `https://discord.com/api/guilds/${message.guild.id}/members/${user.id}`,
                    {
                        headers: {
                            Authorization: `Bot ${client.token}`,
                        },
                    }
                );
                if (guildMemberData && guildMemberData.data && guildMemberData.data.banner) {
                    serverBanner = `https://cdn.discordapp.com/guilds/${message.guild.id}/users/${user.id}/avatars/${guildMemberData.data.banner}${
                        guildMemberData.data.banner.startsWith('a_') ? '.gif' : '.png'
                    }?size=4096`;
                }
            } catch (error) {
                console.error('Error fetching guild member banner:', error);
            }

            // Initial embed
            const embed = new EmbedBuilder()
                .setColor(client.color)
                .setDescription(userBanner ? `User Banner of ${user.tag}` : `User Banner not found for ${user.tag}`)
                .setFooter({ text: `Requested by: ${message.author.tag}` });

            if (userBanner) {
                embed.setImage(userBanner);
            }

            // Buttons to toggle
            const buttons = new ActionRowBuilder().addComponents(
                new ButtonBuilder()
                    .setCustomId('user_banner')
                    .setLabel('User Banner')
                    .setStyle(ButtonStyle.Primary)
                    .setDisabled(!userBanner),
                new ButtonBuilder()
                    .setCustomId('server_banner')
                    .setLabel('Server Banner')
                    .setStyle(ButtonStyle.Secondary)
                    .setDisabled(!serverBanner)
            );

            const msg = await message.channel.send({ embeds: [embed], components: [buttons] });

            // Collector for buttons
            const filter = (interaction) => interaction.isButton() && interaction.user.id === message.author.id;
            const collector = msg.createMessageComponentCollector({ filter, componentType: ComponentType.Button, time: 60000 });

            collector.on('collect', async (interaction) => {
                if (interaction.customId === 'user_banner') {
                    embed.setDescription(`User Banner of ${user.tag}`);
                    embed.setImage(userBanner);
                    await interaction.update({ embeds: [embed] });
                } else if (interaction.customId === 'server_banner') {
                    embed.setDescription(`Server Banner of ${user.tag}`);
                    embed.setImage(serverBanner);
                    await interaction.update({ embeds: [embed] });
                }
            });

            collector.on('end', () => {
                const disabledButtons = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setCustomId('user_banner')
                        .setLabel('User Banner')
                        .setStyle(ButtonStyle.Primary)
                        .setDisabled(true),
                    new ButtonBuilder()
                        .setCustomId('server_banner')
                        .setLabel('Server Banner')
                        .setStyle(ButtonStyle.Secondary)
                        .setDisabled(true)
                );
                msg.edit({ components: [disabledButtons] });
            });
        } catch (error) {
            console.error('Error fetching user banner:', error);
            return message.reply({ content: 'An error occurred while fetching the user banner..!!' });
        }
    },
};

// Function to resolve a user from mention or ID
async function getUserFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@!?(\d+)>$/);
    if (!matches) return null;
    const id = matches[1];
    return await message.client.users.fetch(id).catch(() => null);
}
